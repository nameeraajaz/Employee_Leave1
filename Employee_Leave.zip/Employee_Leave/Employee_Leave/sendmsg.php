<?php
// Required if your environment does not handle autoloading
require __DIR__ . '/vendor/autoload.php';

// Use the REST API Client to make requests to the Twilio REST API
use Twilio\Rest\Client;

// Your Account SID and Auth Token from twilio.com/console
$sid = 'AC813ce62288485b76bc6714b733ada4e0';
$token = 'cf492bc47e5f838b05c2a275a801f502';
$client = new Client($sid, $token);

if(isset($_GET['num']) and isset($_GET['msg']))
		{
			//echo "<div class = 'error'><b><u>".htmlspecialchars($_GET['err'])."</u></b></div><br/>";
            $message = htmlspecialchars($_GET['msg']);
            $mobileno = '+91';
            $mobileno .= htmlspecialchars($_GET['num']);
		

            // Use the client to do fun stuff like send text messages!
            $client->messages->create(
                // the number you'd like to send the message to
                $mobileno,
                array(
                    // A Twilio phone number you purchased at twilio.com/console
                    'from' => '+19415319684',
                    // the body of the text message you'd like to send
                    'body' => $message
                )
            );
            header("Location: {$_SERVER['HTTP_REFERER']}");
        }