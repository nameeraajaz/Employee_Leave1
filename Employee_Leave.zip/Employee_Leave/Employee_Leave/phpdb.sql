-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 13, 2020 at 02:20 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `phpdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `EmpPass` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `UserName`, `EmpPass`) VALUES
(1, 'admin_1', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `director`
--

CREATE TABLE IF NOT EXISTS `director` (
`id` int(11) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `EmpPass` varchar(200) NOT NULL,
  `EmpName` varchar(50) NOT NULL,
  `EmpEmail` varchar(40) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `Mobile` bigint(20) NOT NULL,
  `image` longblob NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `director`
--

INSERT INTO `director` (`id`, `UserName`, `EmpPass`, `EmpName`, `EmpEmail`, `DateOfBirth`, `Mobile`, `image`) VALUES
(1, 'director_1', 'director', 'Aditya', 'aditya@gmail.com', '0000-00-00', 9699699299, '');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
`id` int(11) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `EmpPass` varchar(200) NOT NULL,
  `EmpName` varchar(50) NOT NULL,
  `EmpEmail` varchar(40) NOT NULL,
  `Mobile` bigint(20) NOT NULL,
  `Dept` varchar(30) NOT NULL,
  `EarnLeave` int(5) unsigned NOT NULL,
  `SickLeave` int(5) unsigned NOT NULL,
  `CasualLeave` int(5) unsigned NOT NULL,
  `SpecialLeave` int(10) unsigned NOT NULL,
  `OutdoorLeave` int(10) unsigned NOT NULL,
  `LeaveWithoutPay` int(10) unsigned NOT NULL,
  `CompensatoryLeave` int(10) unsigned NOT NULL,
  `SummerVacation` int(10) unsigned NOT NULL,
  `WinterVacation` int(10) unsigned NOT NULL,
  `DateOfJoin` date NOT NULL,
  `Designation` varchar(40) NOT NULL,
  `Faculty` varchar(40) NOT NULL,
  `EmpType` varchar(40) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `image` longblob NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `UserName`, `EmpPass`, `EmpName`, `EmpEmail`, `Mobile`, `Dept`, `EarnLeave`, `SickLeave`, `CasualLeave`, `SpecialLeave`, `OutdoorLeave`, `LeaveWithoutPay`, `CompensatoryLeave`, `SummerVacation`, `WinterVacation`, `DateOfJoin`, `Designation`, `Faculty`, `EmpType`, `DateOfBirth`, `image`) VALUES
(1, 'emp_1', 'employee', 'Akash', 'akash@gmail.com', 9773972355, 'IT', 0, 6, 8, 7, 0, 0, 0, 30, 40, '2019-10-01', 'Trainer', 'Teaching', 'Permanent', '2000-08-01', ''),
(2, 'emp_2', 'employee2', 'Hitesh', 'hitesh@gmail.com', 1234567899, 'IT', 0, 10, 8, 7, 0, 0, 0, 30, 40, '2019-08-01', 'Trainer', 'Teaching', 'Permanent', '1999-09-01', ''),
(3, 'emp_3', 'emp3', 'Sohel Rashidi', 'sohel@gmail.com', 1234567890, 'IT', 0, 10, 8, 7, 0, 0, 0, 30, 40, '2020-01-10', 'Trainer', 'Teaching', 'Permanent', '2020-01-10', ''),
(4, 'emp_4', 'emp3', 'aniket', 'aniket@gmail.com', 1234567890, 'IT', 0, 10, 8, 7, 0, 0, 0, 30, 40, '2020-01-10', 'Trainer', 'Teaching', 'Permanent', '2020-01-10', ''),
(5, 'emp_123', 'emp123', 'Amit Shah', 'amit@gmail.com', 9987653421, 'CS', 0, 10, 8, 7, 0, 0, 0, 0, 0, '2020-01-17', 'Clerk', 'Non-Teaching', 'Permanent', '1989-03-17', ''),
(25, 'emp_8', 'employee8', 'Umesh Patil', 'umesh@gmail.com', 9773972355, 'EXTC', 0, 0, 8, 0, 0, 0, 0, 7, 7, '2020-01-16', 'Trainer', 'Teaching', 'Temporary', '1997-02-05', ''),
(34, 'emp_10', 'Arya@123', 'Arya', 'arya@gmail.com', 8521479630, 'IT', 0, 0, 8, 0, 0, 0, 0, 7, 7, '2020-09-14', 'Trainer', 'Teaching', 'Temporary', '2020-09-06', 0x322e6a7067);

-- --------------------------------------------------------

--
-- Table structure for table `emp_leaves`
--

CREATE TABLE IF NOT EXISTS `emp_leaves` (
`Id` int(11) NOT NULL,
  `EmpName` varchar(50) NOT NULL,
  `LeaveType` varchar(60) NOT NULL,
  `RequestDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `LeaveDays` int(11) NOT NULL,
  `Reason` text NOT NULL,
  `Status` varchar(20) NOT NULL DEFAULT 'Requested',
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `Dept` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_leaves`
--

INSERT INTO `emp_leaves` (`Id`, `EmpName`, `LeaveType`, `RequestDate`, `LeaveDays`, `Reason`, `Status`, `StartDate`, `EndDate`, `Dept`) VALUES
(1, 'Akash', 'Earned Leave', '2020-01-11 16:35:32', 2, 'yuyuk', 'Rejected', '2020-01-12', '2020-01-13', 'IT'),
(2, 'Akash', 'Sick Leave', '2020-01-15 18:01:20', 2, 'SDSD', 'Granted', '2020-01-16', '2020-01-17', 'IT'),
(3, 'Akash', 'Earned Leave', '2020-09-13 11:36:30', 2, 'h', 'Requested', '2020-09-08', '2020-09-15', 'IT'),
(4, 'Akash', 'Casual Leave', '2020-09-13 11:36:54', 2, 'swa', 'Requested', '2020-09-14', '2020-09-15', 'IT'),
(5, 'Akash', 'Casual Leave', '2020-09-13 12:44:16', 0, 's', 'Requested', '2020-09-14', '2020-09-15', 'IT'),
(6, 'Akash', 'Casual Leave', '2020-09-13 12:44:48', 0, 's', 'Requested', '2020-09-14', '2020-09-15', 'IT'),
(7, 'Akash', 'Casual Leave', '2020-09-13 12:45:14', 0, 's', 'Requested', '2020-09-14', '2020-09-15', 'IT'),
(8, 'Arya', 'Earned Leave', '2020-09-13 17:48:09', 0, 'aa', 'Requested', '2020-09-22', '2020-09-08', 'IT');

-- --------------------------------------------------------

--
-- Table structure for table `hod`
--

CREATE TABLE IF NOT EXISTS `hod` (
`id` int(11) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `EmpPass` varchar(200) NOT NULL,
  `EmpName` varchar(50) NOT NULL,
  `EmpEmail` varchar(40) NOT NULL,
  `Mobile` bigint(20) NOT NULL,
  `Dept` varchar(30) NOT NULL,
  `EarnLeave` int(5) unsigned NOT NULL,
  `SickLeave` int(5) unsigned NOT NULL,
  `CasualLeave` int(5) unsigned NOT NULL,
  `SpecialLeave` int(10) unsigned NOT NULL,
  `OutdoorLeave` int(10) unsigned NOT NULL,
  `LeaveWithoutPay` int(10) unsigned NOT NULL,
  `CompensatoryLeave` int(10) unsigned NOT NULL,
  `SummerVacation` int(10) unsigned NOT NULL,
  `WinterVacation` int(10) unsigned NOT NULL,
  `DateOfJoin` date NOT NULL,
  `DateOfBirth` date NOT NULL,
  `image` longblob NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hod`
--

INSERT INTO `hod` (`id`, `UserName`, `EmpPass`, `EmpName`, `EmpEmail`, `Mobile`, `Dept`, `EarnLeave`, `SickLeave`, `CasualLeave`, `SpecialLeave`, `OutdoorLeave`, `LeaveWithoutPay`, `CompensatoryLeave`, `SummerVacation`, `WinterVacation`, `DateOfJoin`, `DateOfBirth`, `image`) VALUES
(1, 'hod_1', 'hod1', 'Priti', 'priti@gmail.com', 9987448567, 'IT', 0, 10, 6, 0, 0, 0, 0, 30, 40, '2016-04-15', '1990-10-01', '');

-- --------------------------------------------------------

--
-- Table structure for table `hod_leaves`
--

CREATE TABLE IF NOT EXISTS `hod_leaves` (
`Id` int(11) NOT NULL,
  `EmpName` varchar(50) NOT NULL,
  `LeaveType` varchar(60) NOT NULL,
  `RequestDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `LeaveDays` int(11) NOT NULL,
  `Reason` text NOT NULL,
  `Status` varchar(20) NOT NULL DEFAULT 'Requested',
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `Dept` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hod_leaves`
--

INSERT INTO `hod_leaves` (`Id`, `EmpName`, `LeaveType`, `RequestDate`, `LeaveDays`, `Reason`, `Status`, `StartDate`, `EndDate`, `Dept`) VALUES
(1, 'Priti', 'Casual Leave', '2020-01-10 08:27:42', 2, 'dddd', 'Granted', '2020-01-11', '2020-01-12', 'IT'),
(2, 'Priti', 'Earned Leave', '2020-01-15 18:03:55', 2, 'feff', 'Requested', '2020-01-16', '2020-01-17', 'IT');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `director`
--
ALTER TABLE `director`
 ADD UNIQUE KEY `id` (`id`), ADD UNIQUE KEY `UserName` (`UserName`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
 ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `emp_leaves`
--
ALTER TABLE `emp_leaves`
 ADD PRIMARY KEY (`Id`), ADD UNIQUE KEY `id` (`Id`), ADD UNIQUE KEY `id_2` (`Id`);

--
-- Indexes for table `hod`
--
ALTER TABLE `hod`
 ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `hod_leaves`
--
ALTER TABLE `hod_leaves`
 ADD PRIMARY KEY (`Id`), ADD UNIQUE KEY `id` (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `director`
--
ALTER TABLE `director`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `emp_leaves`
--
ALTER TABLE `emp_leaves`
MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `hod`
--
ALTER TABLE `hod`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `hod_leaves`
--
ALTER TABLE `hod_leaves`
MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
