
<?php
session_start();
?>
<html>
<head>
<title>::Leave Management::</title>
</head>
<body>
<?php
include 'clientnavi3.php';
include 'connect.php';

if(filter_var($_GET['id'],FILTER_VALIDATE_INT) && filter_var($_GET['empid'],FILTER_VALIDATE_INT))
	{
		$id =$_GET['id'];
		$empid =$_GET['empid'];
	}
else
	{
		header('location:home.php');
	}
if(isset($_SESSION['hoduser']))
	{
	$sql = "SELECT EmpName,LeaveType,RequestDate,Status,LeaveDays,StartDate,EndDate FROM emp_leaves WHERE Id='".$id."'";
	$result = $conn->query($sql);
	if($result->num_rows > 0)
		{
		while($row = $result->fetch_assoc())
			{
			$leavedays = $row["LeaveDays"];
			$sql2 = "SELECT EarnLeave,SickLeave,CasualLeave,SpecialLeave,OutdoorLeave,LeaveWithoutPay,CompensatoryLeave,EmpEmail FROM employees WHERE id = '".$empid."'";
			$result2 = $conn->query($sql2);
			if($result2->num_rows > 0)
				{
				while($row2 = $result2->fetch_assoc())
					{
					$earnleave = $row2["EarnLeave"];
					$diff1 = $earnleave-$leavedays;
					$sickleave = $row2["SickLeave"];
					$diff2 = $sickleave-$leavedays;
					$casualleave = $row2["CasualLeave"];
					$diff3 = $casualleave-$leavedays;
					$specialleave = $row2["SpecialLeave"];
					$diff4 = $specialleave-$leavedays;
					$outdoorleave = $row2["OutdoorLeave"];
					$diff5 = $outdoorleave-$leavedays;
					$LWPleave = $row2["LeaveWithoutPay"];
					$diff6 = $LWPleave-$leavedays;
					$Compleave = $row2["CompensatoryLeave"];
					$diff7 = $Compleave-$leavedays;
					//$email = $row2["EmpEmail"];

					if($row["LeaveType"] == "Earned Leave")
						{
						if($diff1 < 0)
						{
							echo "<script type='text/javascript'>alert('Earn Leave Over!');</script>";
							header( "refresh:1;url=view_leaves.php" );
							exit();
						}
						else
							$sql3 = "UPDATE employees SET EarnLeave = '".$diff1."' WHERE id = '".$empid."'";
						}
					else if($row["LeaveType"] == "Sick Leave")
						{
						if($diff2 < 0)
						{
							echo "<script type='text/javascript'>alert('Sick Leaves Over!');</script>";
							header( "refresh:1;url=view_leaves.php" );
							exit();
						}
						else
							$sql3 = "UPDATE employees SET SickLeave = '".$diff2."' WHERE id = '".$empid."'";
						}
					else if($row["LeaveType"] == "Casual Leave")
						{
						if($diff3 < 0)
						{
							echo "<script type='text/javascript'>alert('Causual Leaves Over!');</script>";
							header( "refresh:1;url=view_leaves.php" );
							exit();
						}
						else
							$sql3 = "UPDATE employees SET CasualLeave = '".$diff3."' WHERE id = '".$empid."'";
						}
					else if($row["LeaveType"] == "Special Leave")
						{
						if($diff4 < 0)
						{
							echo "<script type='text/javascript'>alert('Special Leaves Over!');</script>";
							header( "refresh:1;url=view_leaves.php" );
							exit();
						}
						else
							$sql3 = "UPDATE employees SET SpecialLeave = '".$diff4."' WHERE id = '".$empid."'";
						}
					else if($row["LeaveType"] == "Outdoor Leave")
						{
						if($diff5 < 0)
						{
							echo "<script type='text/javascript'>alert('Outdoor Leaves Over!');</script>";
							header( "refresh:1;url=view_leaves.php" );
							exit();
						}
						else
							$sql3 = "UPDATE employees SET OutdoorLeave = '".$diff5."' WHERE id = '".$empid."'";
						}
					else if($row["LeaveType"] == "Leave Without Pay")
						{
						if($diff6 < 0)
						{
							echo "<script type='text/javascript'>alert('LeaveWithoutPay Leaves Over!');</script>";
							header( "refresh:1;url=view_leaves.php" );
							exit();
						}
						else
							$sql3 = "UPDATE employees SET LeaveWithoutPay = '".$diff6."' WHERE id = '".$empid."'";
						}
					else if($row["LeaveType"] == "Compensatory Leave")
						{
						if($diff7 < 0)
						{
							echo "<script type='text/javascript'>alert('Compensatory Leaves Over!');</script>";
							header( "refresh:1;url=view_leaves.php" );
							exit();
						}
						else
							$sql3 = "UPDATE employees SET CompensatoryLeave = '".$diff7."' WHERE id = '".$empid."'";
						}
					
					if($conn->query($sql3) === TRUE)
							{
							$sql4 = "UPDATE emp_leaves SET Status = 'Granted' WHERE Id = '".$id."'";
							if($conn->query($sql4) === TRUE)
								{
									echo "<script type='text/javascript'>alert('Leave Granted successfully!');</script>";
									header( "refresh:1;url=view_leaves.php" );
								}
							}
					}
				}
			
			}
		}
	}
	else
		{
			header('location:index.php?err='.urlencode('Please Login First To Access This Page !'));
		}
?>
</div>
</body>
</html>