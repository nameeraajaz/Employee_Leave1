<html>
<head>
<title>::Leave Management::</title>
<!------ Include the above in your HEAD tag ---------->
</head>
<body style="align-items:center;">

<?php
session_start();
if(isset($_SESSION['hoduser']))
{ 
  include 'clientnavi3.php';	
  include 'connect.php';
  $user = $_SESSION['hoduser'];
  $sql="SELECT * FROM hod WHERE  UserName = '".$user."'";
  $result = $conn->query($sql);
      if ($result->num_rows > 0) {
              while($row = $result->fetch_assoc()) {
                  $Name=$row["EmpName"];
                  $Dept=$row["Dept"];
                  }
                }
if(isset($_POST['submit']))
{ // Fetching variables of the form which travels in URL
$Ltype = $_POST['type'];
$Lfrom = $_POST['from'];
$Lto = $_POST['to'];
$Ldays = $_POST['days'];
$Lreason = $_POST['reason'];
//if($name !=''||$email !=''){
//Insert Query of SQL
$sql = "INSERT INTO hod_leaves(EmpName, LeaveType, LeaveDays, Reason, StartDate, EndDate, Dept) values ('$Name', '$Ltype', '$Ldays','$Lreason','$Lfrom','$Lto','$Dept')";
if ($conn->query($sql) === TRUE) {
echo "<script type='text/javascript'>alert('Leave Applied Successfully');</script>";
}
else{
echo "<script type='text/javascript'>alert('Error!Please try again.');</script>";
}
}
}
else
{
    header('location:../signin.php?err='.urlencode('Please Login First For Accessing This Page !'));
    exit();
}
//mysql_close($connection); // Closing Connection with Server
?>

<div class='container' >
                    <!-- form card login -->
<div class="card rounded-0 col align-self-center" style="padding-left:20px;padding-right:20px;padding-top:10px;padding-bottom:10px; background-color:white;" >
<div class="card-header">
    <h3 class="mb-0">Apply Leave</h3>
</div>
<hr/>
<div class="card-body">
<form class="form-horizontal" method="post">

<!-- Select Multiple -->
<div class="form-group ">
  <label class="col-md-4 control-label" for="selectmultiple">Leave Type:</label>
  <div class="col-md-6">
  <select class="form-control" name="type" required>
              <option>Casual Leave</option>
              <option>Earned Leave</option>
              <option>Sick Leave</option>
              <option>Special Leave</option>
              <option>Outdoor Leave</option>
              <option>Leave Without Pay</option>
              <option>Compensatory Leave</option>
            </select>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">From:</label>  
  <div class="col-md-6">
  <input id="textinput" name="from" type="date" placeholder="placeholder" class="form-control input-md" required>  
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">To:</label>  
  <div class="col-md-6">
  <input id="textinput" name="to" type="date" placeholder="placeholder" class="form-control input-md" required> 
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">No. of Days</label>  
  <div class="col-md-6">
  <input id="textinput" name="days" type="text" placeholder="placeholder" class="form-control input-md" required>
  </div>
</div>

<!-- Textarea -->
<div class="form-group">
  <label class="col-md-4 control-label" for="textarea">Reason:</label>
  <div class="col-md-8">                     
    <textarea class="form-control" id="textarea" name="reason" required></textarea>
  </div>
</div>

<!-- Button (Double) -->
<div class="form-group">
  <div class="col-sm-8">
    <button id="button1id" name="submit" class="btn btn-primary ">Submit</button>
    <!--button id="button2id" name="button2id" class="btn btn-danger ">Cancel</button-->
  </div>
</div>

</form>
</div>
</div>            
</body>
</html>