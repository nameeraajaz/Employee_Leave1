
<?php
session_start();
?>
<html>
<head>
<title>::Leave Management::</title>
</head>
<body>
<?php
include 'clientnavi3.php';
include 'connect.php';

if(filter_var($_GET['id'],FILTER_VALIDATE_INT) && filter_var($_GET['empid'],FILTER_VALIDATE_INT))
	{
		$id =$_GET['id'];
		$empid =$_GET['empid'];
	}
else
	{
		header('location:home.php');
	}
if(isset($_SESSION['directoruser']))
	{
	
	$sql = "SELECT * FROM emp_leaves WHERE Id='".$id."'";
	$result = $conn->query($sql);
	if($result->num_rows > 0)
		{
		while($row = $result->fetch_assoc())
			{
				$sql2 = "SELECT id,EmpEmail FROM employees WHERE id = '".$empid."'";
				$result2 = $conn->query($sql2);
				if($result2->num_rows > 0)
					{
						while($row2 = $result2->fetch_assoc())
							{
							//$email = $row2['EmpEmail'];
							$sql3 = "UPDATE hod_leaves SET Status = 'Rejected' WHERE Id = '".$id."'";
							if($conn->query($sql3) === TRUE)
									{
										echo "<script type='text/javascript'>alert('Leave Rejected successfully!');</script>";
										header( "refresh:1;url=view_leaves.php" );
									}	
							}
					}
			}
		}
	}
else
	{
		header('location:../signin.php?err='.urlencode('Please Login First For Accessing This Page !'));
		exit();
	}
?>
</div>
</body>
</html>