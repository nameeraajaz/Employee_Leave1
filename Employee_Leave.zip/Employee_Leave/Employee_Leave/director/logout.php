<?php
session_start();
session_unset();
session_destroy();
header('location:../signin.php?err='.urlencode('You Have Logged Out Succesfully'));
exit();
?>