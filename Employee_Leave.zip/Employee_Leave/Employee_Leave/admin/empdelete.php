<title>::Leave Management::</title>
<?php
session_start();
if(isset($_SESSION['adminuser']))
	{
    include 'connect.php';
    include 'adminnavi3.php';
	if(filter_var($_GET['id'],FILTER_VALIDATE_INT))
		{
			$id = $_GET['id'];
		}
	else
		{
			header('location:home.php');
        }
    if($_GET['user']=='emp')
    {
        $sql = "DELETE FROM employees WHERE id='".$id."'";
    }
    else
    {
        $sql = "DELETE FROM hod WHERE id='".$id."'";
    }
	if ($conn->query($sql) === TRUE)
		{
		header('location:home.php?msg='.urlencode('Employee Successfully Removed !'));
		}
	else
		{
		header('location:home.php?msg='.urlencode('Error Removing Employee !'));
		}
	$conn->close();
	}
else
	{
	header('location:../signin.php?err='.urlencode('Please login first to access this page !'));
	}
?>