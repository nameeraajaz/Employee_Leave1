<title>::Leave Management::</title>
<div class = "textview">
<?php
session_start();
if(isset($_SESSION['adminuser']))
	{
	include 'connect.php';
	include 'adminnavi3.php';
    $sql = "SELECT * FROM employees";
    $sql2 = "SELECT * FROM hod";
	$result2 = $conn->query($sql2);
	$result = $conn->query($sql);
	if($result->num_rows > 0 )
		{
				echo '<h1 style="color:#009688;text-shadow: 0px 0px 2px #000000;text-align:center">';
				echo 'All Employees</h1>';
				echo "<div class='container'>";
				echo "<table class='table table-bordered' style='background-color: #ffffff;'>";
				echo "<tr><th>Employee Name</th>";
				echo "<th>Employee Email</th>";
				echo "<th>Department</th>";
				echo "<th>Date of Joining</th>";
				echo "<th>Designation</th>";
                echo "<th>Action</th>";
		while($row = $result->fetch_assoc())
			{
					echo "<tr><td>".$row["EmpName"]."</td>";
					echo "<td>".$row["EmpEmail"]."</td>";
					echo "<td>".$row["Dept"]."</td>";
					echo "<td>".$row["DateOfJoin"]."</td>";
					echo "<td>".$row["Designation"]."</td>";
                    echo "<td><a href = 'empdelete.php?id=".$row["id"]."&user=emp'>Delete</a></td></tr>";
            }
            while($row2 = $result2->fetch_assoc())
			{
					echo "<tr><td>".$row2["EmpName"]."</td>";
					echo "<td>".$row2["EmpEmail"]."</td>";
					echo "<td>".$row2["Dept"]."</td>";
					echo "<td>".$row2["DateOfJoin"]."</td>";
					echo "<td>HOD</td>";
                    echo "<td><a href = 'empdelete.php?id=".$row2["id"]."&user=hod'>Delete</a></td></tr>";
			}
				echo "</table>";
				echo "</center>";
				echo "</div>";
            }
    }
else
	{
	header('location:index.php?err='.urlencode('Please Login First To Access This Page !'));
	exit();
	}
?>
</div>