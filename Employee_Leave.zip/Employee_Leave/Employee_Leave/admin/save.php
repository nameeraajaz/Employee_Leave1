<?php
session_start();
if(isset($_SESSION['adminuser']))
{ 
  //include 'adminnavi3.php';	
  include 'connect.php';
  //$user = $_SESSION['adminuser'];
    if(isset($_POST['submit']))
    { // Fetching variables of the form which travels in URL
           
        $target="image/".basename($_FILES['image']['name']);
        $image=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
        // $file=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
        $Name = $_POST['nameinput'];
        $Username = $_POST['usrnminput'];
        $Pass = $_POST['passinput'];
        $Email = $_POST['emailinput'];
        $Dept = $_POST['selectdept'];
        $DOJ = $_POST['dojinput'];
        $Desig = $_POST['desiginput'];
        $Category = $_POST['selectempis'];
        $Type = $_POST['selecttype'];
        $DOB = $_POST['dobinput'];
        $Mobile = $_POST['mobinput'];
        $flag = 0;
        if(preg_match("/emp/",$Username))
            {
                $sql="SELECT * FROM employees WHERE  UserName = '".$Username."'";
            }
        elseif(preg_match("/hod/",$Username))
            {
                $sql="SELECT * FROM hod WHERE  UserName = '".$Username."'";
            }
        elseif(preg_match("/director/",$Username))
            {
                $sql="SELECT * FROM director WHERE  UserName = '".$Username."'";
            }

        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            header('location:register.php?err='.urlencode('Username already exists!'));
            $flag = 1;
            exit();
        }

        if($flag==0)
        {
            if(preg_match("/emp/",$Username))
            {
               if($Category=='Teaching')
               {
                   if($Type=='Permanent')
                   {
                        $sql = "INSERT INTO employees(UserName, EmpPass, EmpName, EmpEmail, Mobile, Dept, EarnLeave, SickLeave, CasualLeave, SpecialLeave, OutdoorLeave, LeaveWithoutPay, CompensatoryLeave, SummerVacation, WinterVacation, DateOfJoin, Designation, Faculty, EmpType, DateOfBirth,image) values 
                        ('$Username','$Pass','$Name','$Email', '$Mobile', '$Dept', 0,10,8,7,0,0,0,30,40, '$DOJ', '$Desig', '$Category', '$Type', '$DOB',$image)";
                   }
                   if($Type=='Temporary')
                   {
                        $sql = "INSERT INTO employees(UserName, EmpPass, EmpName, EmpEmail, Mobile, Dept, EarnLeave, SickLeave, CasualLeave, SpecialLeave, OutdoorLeave, LeaveWithoutPay, CompensatoryLeave, SummerVacation, WinterVacation, DateOfJoin, Designation, Faculty, EmpType, DateOfBirth,image) values 
                        ('$Username','$Pass','$Name','$Email', '$Mobile', '$Dept', 0,0,8,0,0,0,0,7,7, '$DOJ', '$Desig', '$Category', '$Type', '$DOB', '$image)";
                   }
               }
               elseif($Category=='Non-Teaching')
               {
                    if($Type=='Permanent')
                    {
                        $sql = "INSERT INTO employees(UserName, EmpPass, EmpName, EmpEmail, Mobile, Dept, EarnLeave, SickLeave, CasualLeave, SpecialLeave, OutdoorLeave, LeaveWithoutPay, CompensatoryLeave, SummerVacation, WinterVacation, DateOfJoin, Designation, Faculty, EmpType, DateOfBirth,image) values 
                        ('$Username','$Pass','$Name','$Email', '$Mobile', '$Dept', 0,10,8,7,0,0,0,0,0, '$DOJ', '$Desig', '$Category', '$Type', '$DOB', '$image')";
                    }
                    if($Type=='Temporary')
                    {
                        $sql = "INSERT INTO employees(UserName, EmpPass, EmpName, EmpEmail, Mobile, Dept, EarnLeave, SickLeave, CasualLeave, SpecialLeave, OutdoorLeave, LeaveWithoutPay, CompensatoryLeave, SummerVacation, WinterVacation, DateOfJoin, Designation, Faculty, EmpType, DateOfBirth,image) values 
                        ('$Username','$Pass','$Name','$Email', '$Mobile', '$Dept', 0,0,0,0,0,0,0,0,0, '$DOJ', '$Desig', '$Category', '$Type', '$DOB','$image')";
                    }
               }
            }
        elseif(preg_match("/hod/",$Username))
            {
                $sql = "INSERT INTO hod(UserName, EmpPass, EmpName, EmpEmail, Mobile, Dept, EarnLeave, SickLeave, CasualLeave, SpecialLeave, OutdoorLeave, LeaveWithoutPay, CompensatoryLeave, SummerVacation, WinterVacation, DateOfJoin, DateOfBirth, image) values ('$Username', '$Pass','$Name','$Email','$Mobile','$Dept',0,10,8,7,0,0,0,30,40,$DOJ,$DOB, '$image')";
            }
        elseif(preg_match("/director/",$Username))
            {
                $sql="INSERT INTO director(UserName, EmpPass, EmpName, EmpEmail, DateOfBirth, Mobile,image) values ('$Username','$Pass','$Name','$Email','$DOB', '$Mobile','$image')";
            }

        if ($conn->query($sql) === TRUE) {
            if(move_uploaded_file($_FILES['image']['tmp_name'],$target)){
                $message1 = "User Registered Successfully!";
                header('location:register.php?err='.urlencode($message1));
                exit();
            }
            else{
                echo"";
            }
            //$msg="Leave Application Credentials are Username: $Username and Password: $Pass";
            //$num=$Mobile;
           
			//echo "<script type='text/javascript'>alert('$message1');</script>";
            //header('refresh:1;url=../sendmsg.php?msg='.urlencode($msg).'&num='.urlencode($num));
            
        }
        else{
            header('location:register.php?err='.urlencode('Error while registering!'));
            exit();
            }
        }
    }
    header('location:register.php');
    exit();
}
else
{
    header('location:index.php?err='.urlencode('Please Login First For Accessing This Page !'));
    exit();
}
//mysql_close($connection); // Closing Connection with Server
?>

