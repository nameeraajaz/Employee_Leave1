<?php
session_start();
include 'connect.php';

$username = $_POST['uname'];
$password = $_POST['pass'];

if(preg_match("/emp/",$username))
{
	$sql = "SELECT * FROM employees WHERE UserName='" . $username. "'and EmpPass='". $password."'";
}
elseif(preg_match("/hod/",$username))
{
	$sql = "SELECT * FROM hod WHERE UserName='" . $username. "'and EmpPass = '". $password."'";
}
elseif(preg_match("/director/",$username))
{
	$sql = "SELECT * FROM director WHERE UserName='" . $username. "' and EmpPass = '". $password."'";
}
else
{
	$sql = "SELECT * FROM admins WHERE UserName='" . $username. "' and EmpPass = '". $password."'";
}

$result = $conn->query($sql);

//while($row = $result->fetch_assoc()) {
        if($result->num_rows>0)
			{
			if(preg_match("/emp/",$username))
			{
				$_SESSION['empuser'] = $username;
				header('location:employee/home.php');
			}
			elseif(preg_match("/hod/",$username))
			{
				$_SESSION['hoduser'] = $username;
				header('location:hod/home.php');
			}
			
			elseif(preg_match("/director/",$username))
			{
				$_SESSION['directoruser'] = $username;
				header('location:director/home.php');
			}
			else
			{
				$_SESSION['adminuser'] = $username;
				header('location:admin/home.php');
			}
		}
		else
			{
			header('location:signin.php?err='.urlencode('Username Or Password Incorrect'));
			}
    //}	
?>